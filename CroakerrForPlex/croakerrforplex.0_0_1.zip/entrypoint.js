'use strict';

var __importDefault = (undefined && undefined.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.disable = exports.enable = void 0;
var logo = "https://avatars.githubusercontent.com/u/324832";
var url = "https://discordapp.com/api/webhooks/992454432916766930/db_hAFzowWd2uMxY8sam0HXaeSBkvCgDOCOusOwn5AuJwpN8t5dYkTCMy6lojPAXUEll";
var axios_1 = __importDefault(require("axios"));
function enable(_a) {
    var croakerr = _a.croakerr, logger = _a.logger;
    axios_1.default.get("https://example.com");
    logger.debug("Incoming log message from Plex plugin");
    croakerr.registerListener("plex.library.new", function (data) { return handleLibraryContent(croakerr, logger, data); });
}
exports.enable = enable;
function disable() {
}
exports.disable = disable;
function handleLibraryContent(croakerr, logger, data) {
    logger.log("Received Plex library payload");
    var fields = [];
    if (data.Metadata.audienceRating) {
        fields.push({
            name: "Audience Rating",
            value: data.Metadata.audienceRating
        });
    }
    switch (data.Metadata.librarySectionType) {
        case "artist":
            croakerr.send(url, {
                username: croakerr.manifest.name,
                avatar_url: logo,
                embeds: [
                    {
                        color: 0xe5a00d,
                        type: "rich",
                        title: "New Music Added",
                        description: "From artist: ".concat(data.Metadata.title)
                    }
                ]
            });
            break;
        case "show":
            croakerr.send(url, {
                username: croakerr.manifest.name,
                avatar_url: logo,
                embeds: [
                    {
                        color: 0xe5a00d,
                        type: "rich",
                        title: "New Episode Available",
                        description: "Now Airing: ".concat(data.Metadata.title),
                        fields: fields
                    }
                ]
            });
            break;
        case "movie":
            croakerr.send(url, {
                username: croakerr.manifest.name,
                avatar_url: logo,
                embeds: [
                    {
                        color: 0xe5a00d,
                        type: "rich",
                        title: "New Movie Available",
                        description: "Now Airing: ".concat(data.Metadata.title),
                        fields: fields
                    }
                ]
            });
            break;
        default:
            console.log(data);
    }
}
