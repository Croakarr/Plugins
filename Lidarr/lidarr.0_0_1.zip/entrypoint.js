'use strict';

Object.defineProperty(exports, "__esModule", { value: true });
exports.disable = exports.enable = void 0;
var logo = "https://avatars.githubusercontent.com/u/28475832";
var url = "https://discordapp.com/api/webhooks/992454432916766930/db_hAFzowWd2uMxY8sam0HXaeSBkvCgDOCOusOwn5AuJwpN8t5dYkTCMy6lojPAXUEll";
function enable(_a) {
    var croakerr = _a.croakerr, logger = _a.logger;
    logger.debug("Incoming log message from Lidarr plugin");
    croakerr.registerListener("lidarr.test", function (data) { return handleTest(croakerr, logger); });
    croakerr.registerListener("lidarr.download", function (data) { return handleDownload(croakerr, logger, data); });
    croakerr.registerListener("lidarr.grab", function (data) { return handleGrab(croakerr, logger, data); });
}
exports.enable = enable;
function disable() {
}
exports.disable = disable;
function handleTest(croakerr, logger, data) {
    logger.log("Received Lidarr test payload");
    croakerr.send(url, {
        username: croakerr.manifest.name,
        avatar_url: logo,
        embeds: [
            {
                color: 0x00a65b,
                type: "rich",
                title: "Webhook Test",
                description: "Since this payload is probably being used for debugging purposes anyway, here's some information about the plugin which made it.",
                fields: [
                    {
                        name: "Name",
                        value: croakerr.manifest.name,
                        inline: true
                    },
                    {
                        name: "Version",
                        value: croakerr.manifest.version,
                        inline: true
                    },
                    {
                        name: "Author",
                        value: croakerr.manifest.author,
                        inline: true
                    }
                ]
            }
        ]
    });
}
function handleDownload(croakerr, logger, data) {
    logger.log("Received Lidarr download payload");
    var text = "";
    var totalBytes = 0;
    for (var i = 0; i < data.tracks.length; i++) {
        var track = data.tracks[i];
        totalBytes += data.trackFiles[i].size;
        text += "#".concat(track.trackNumber, " - ").concat(track.title, " - (").concat(track.quality, " - ").concat(bytesToUnit(data.trackFiles[i].size), ")\n");
    }
    croakerr.send(url, {
        username: croakerr.manifest.name,
        avatar_url: logo,
        embeds: [
            {
                color: 0x00a65b,
                type: "rich",
                title: "Download completed",
                description: "Artist: `" + data.artist.name + "`\nTrack Count: " + "".concat(data.tracks.length, "\nSize on Disk: ").concat(bytesToUnit(totalBytes), "\n\n**Tracklist**:\n").concat(text)
            }
        ]
    });
}
function handleGrab(croakerr, logger, data) {
    logger.log("Received Lidarr grab payload");
    croakerr.send(url, {
        username: croakerr.manifest.name,
        avatar_url: logo,
        embeds: [
            {
                color: 0x1d563d,
                type: "rich",
                title: "Download Queued",
                description: "Artist: `" + data.artist.name + "`\nAlbum: " + data.albums[0].title + " (" + new Date(data.albums[0].releaseDate).getUTCFullYear() + ")\nDownload Size: " + "".concat(bytesToUnit(data.release.size))
            }
        ]
    });
}
function bytesToUnit(bytes) {
    if (bytes === 0)
        return '0 Bytes';
    var i = parseInt(Math.floor(Math.log(bytes) / Math.log(1024)) + "");
    return Math.round(bytes / Math.pow(1024, i)) + ' ' + ['Bytes', 'KB', 'MB', 'GB', 'TB'][i];
}
