'use strict';

var __awaiter = (undefined && undefined.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __generator = (undefined && undefined.__generator) || function (thisArg, body) {
    var _ = { label: 0, sent: function() { if (t[0] & 1) throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t, g;
    return g = { next: verb(0), "throw": verb(1), "return": verb(2) }, typeof Symbol === "function" && (g[Symbol.iterator] = function() { return this; }), g;
    function verb(n) { return function (v) { return step([n, v]); }; }
    function step(op) {
        if (f) throw new TypeError("Generator is already executing.");
        while (_) try {
            if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
            if (y = 0, t) op = [op[0] & 2, t.value];
            switch (op[0]) {
                case 0: case 1: t = op; break;
                case 4: _.label++; return { value: op[1], done: false };
                case 5: _.label++; y = op[1]; op = [0]; continue;
                case 7: op = _.ops.pop(); _.trys.pop(); continue;
                default:
                    if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) { _ = 0; continue; }
                    if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) { _.label = op[1]; break; }
                    if (op[0] === 6 && _.label < t[1]) { _.label = t[1]; t = op; break; }
                    if (t && _.label < t[2]) { _.label = t[2]; _.ops.push(op); break; }
                    if (t[2]) _.ops.pop();
                    _.trys.pop(); continue;
            }
            op = body.call(thisArg, _);
        } catch (e) { op = [6, e]; y = 0; } finally { f = t = 0; }
        if (op[0] & 5) throw op[1]; return { value: op[0] ? op[1] : void 0, done: true };
    }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.disable = exports.enable = void 0;
var fs_1 = require("fs");
var logo = "https://avatars.githubusercontent.com/u/28475832";
function enable(_a) {
    var croakarr = _a.croakarr, logger = _a.logger;
    return __awaiter(this, void 0, void 0, function () {
        var config, text, _loop_1, i, e_1;
        return __generator(this, function (_b) {
            switch (_b.label) {
                case 0:
                    _b.trys.push([0, 4, , 5]);
                    config = null;
                    logger.log(__dirname + "/settings.json");
                    if (!!(0, fs_1.existsSync)(__dirname + "/settings.json")) return [3 /*break*/, 2];
                    return [4 /*yield*/, setup(croakarr)];
                case 1:
                    config = _b.sent();
                    logger.debug("Plugin configuration not found.");
                    logger.debug("Commencing guided setup.");
                    (0, fs_1.writeFileSync)(__dirname + "/settings.json", JSON.stringify(config));
                    return [3 /*break*/, 3];
                case 2:
                    text = (0, fs_1.readFileSync)(__dirname + "/settings.json", 'utf-8');
                    try {
                        config = JSON.parse(text);
                    }
                    catch (e) {
                        logger.error("FATAL ERROR - Unable to read configuration.");
                        return [2 /*return*/, [false, e]];
                    }
                    _b.label = 3;
                case 3:
                    if (config !== null) {
                        console.log(config.events);
                        _loop_1 = function (i) {
                            var evt = config.events[i];
                            if (evt.hooks.length > 0) {
                                croakarr.registerListener(evt.event, function (data) {
                                    for (var h = 0; h < evt.hooks.length; h++) {
                                        evt.handler(evt.hooks[h], croakarr, logger, data);
                                    }
                                });
                            }
                        };
                        for (i = 0; i < config.events.length; i++) {
                            _loop_1(i);
                        }
                        return [2 /*return*/, [true, null]];
                    }
                    return [3 /*break*/, 5];
                case 4:
                    e_1 = _b.sent();
                    return [2 /*return*/, [false, e_1]];
                case 5: return [2 /*return*/];
            }
        });
    });
}
exports.enable = enable;
function disable() {
}
exports.disable = disable;
function handleTest(hook, croakarr, logger, data) {
    croakarr.send(hook.url, {
        username: croakarr.manifest.name,
        avatar_url: logo,
        embeds: [
            {
                color: 0x00a65b,
                type: "rich",
                title: "Webhook Test",
                description: "Since this payload is probably being used for debugging purposes anyway, here's some information about the plugin which made it.",
                fields: [
                    {
                        name: "Name",
                        value: croakarr.manifest.name,
                        inline: true
                    },
                    {
                        name: "Version",
                        value: croakarr.manifest.version,
                        inline: true
                    },
                    {
                        name: "Author",
                        value: croakarr.manifest.author,
                        inline: true
                    }
                ]
            }
        ]
    });
}
function handleDownload(hook, croakarr, logger, data) {
    var text = "";
    var totalBytes = 0;
    for (var i = 0; i < data.tracks.length; i++) {
        var track = data.tracks[i];
        totalBytes += data.trackFiles[i].size;
        text += "#".concat(track.trackNumber, " - ").concat(track.title, " - (").concat(track.quality, " - ").concat(bytesToUnit(data.trackFiles[i].size), ")\n");
    }
    croakarr.send(hook.url, {
        username: croakarr.manifest.name,
        avatar_url: logo,
        embeds: [
            {
                color: 0x00a65b,
                type: "rich",
                title: "Download completed",
                description: "Artist: `" + data.artist.name + "`\nTrack Count: " + "".concat(data.tracks.length, "\nSize on Disk: ").concat(bytesToUnit(totalBytes), "\n\n**Tracklist**:\n").concat(text)
            }
        ]
    });
}
function handleGrab(hook, croakarr, logger, data) {
    croakarr.send(hook.url, {
        username: croakarr.manifest.name,
        avatar_url: logo,
        embeds: [
            {
                color: 0x1d563d,
                type: "rich",
                title: "Download Queued",
                description: "Artist: `" + data.artist.name + "`\nAlbum: " + data.albums[0].title + " (" + new Date(data.albums[0].releaseDate).getUTCFullYear() + ")\nDownload Size: " + "".concat(bytesToUnit(data.release.size))
            }
        ]
    });
}
function bytesToUnit(bytes) {
    if (bytes === 0)
        return '0 Bytes';
    var i = parseInt(Math.floor(Math.log(bytes) / Math.log(1024)) + "");
    return Math.round(bytes / Math.pow(1024, i)) + ' ' + ['Bytes', 'KB', 'MB', 'GB', 'TB'][i];
}
var HookService;
(function (HookService) {
    HookService["UNKNOWN"] = "UNKNOWN";
    HookService["DISCORD"] = "Discord";
})(HookService || (HookService = {}));
var HTTP = /https?:\/\/(www\.)?[-a-zA-Z0-9@:%._\+~#=]{1,256}\.[a-zA-Z0-9()]{1,6}\b([-a-zA-Z0-9()@:%_\+.~#?&//=]*)/;
var acceptedDomains = {};
acceptedDomains[HookService.DISCORD] = ["discordapp.com"];
function setup(croakarr, logger) {
    return __awaiter(this, void 0, void 0, function () {
        var core, choices, longest, i, i, name_1, i, subscribe, e, x;
        var _a;
        return __generator(this, function (_b) {
            switch (_b.label) {
                case 0:
                    _a = {};
                    return [4 /*yield*/, setupWebhooks(croakarr)];
                case 1:
                    core = (_a.webhooks = _b.sent(),
                        _a.events = [
                            {
                                name: "Test",
                                shortDesc: "Receive test events from Lidarr",
                                description: "A test event used to ensure that the hooks work correctly.",
                                enabled: false,
                                hooks: [],
                                event: "lidarr.test",
                                handler: handleTest
                            },
                            {
                                name: "Download",
                                shortDesc: "Receive import details from Lidarr",
                                description: "An event emitted when Lidarr imports a completed media asset into the user's library.",
                                enabled: false,
                                hooks: [],
                                event: "lidarr.download",
                                handler: handleDownload
                            },
                            {
                                name: "Grab",
                                shortDesc: "Receive download details from Lidarr",
                                description: "An event emitted when Lidarr grabs an applicable download asset for the user's library.",
                                enabled: false,
                                hooks: [],
                                event: "lidarr.grab",
                                handler: handleGrab
                            }
                        ],
                        _a);
                    choices = [];
                    longest = 0;
                    for (i = 0; i < core.events.length; i++) {
                        if (longest < core.events[i].name.length)
                            longest = core.events[i].name.length;
                        choices.push({ title: core.events[i].name, value: core.events[i].event });
                    }
                    for (i = 0; i < choices.length; i++) {
                        name_1 = core.events[i].name;
                        while (name_1.length < longest + 1) {
                            name_1 += " ";
                        }
                        choices[i].title = name_1 + " - " + core.events[i].shortDesc;
                    }
                    i = 0;
                    _b.label = 2;
                case 2:
                    if (!(i < core.webhooks.length)) return [3 /*break*/, 5];
                    return [4 /*yield*/, croakarr.prompt({
                            type: "multiselect",
                            name: "subscribe",
                            message: "Select which events you want to receive for hook: '" + core.webhooks[i].name + "' (" + core.webhooks[i].service + ")",
                            choices: choices,
                            hint: '- Space to select. Enter to submit'
                        })];
                case 3:
                    subscribe = (_b.sent()).subscribe;
                    for (e = 0; e < core.events.length; e++) {
                        if (subscribe.includes(core.events[e].event)) {
                            x = core.events[e];
                            x.hooks.push(core.webhooks[i]);
                            core.events[e] = x;
                        }
                    }
                    _b.label = 4;
                case 4:
                    i++;
                    return [3 /*break*/, 2];
                case 5:
                    console.log(core.events);
                    return [2 /*return*/, core];
            }
        });
    });
}
function setupWebhooks(croakarr, logger) {
    return __awaiter(this, void 0, void 0, function () {
        var hooks, another, hook, confirm_1;
        return __generator(this, function (_a) {
            switch (_a.label) {
                case 0:
                    hooks = [];
                    another = true;
                    _a.label = 1;
                case 1:
                    if (!another) return [3 /*break*/, 5];
                    return [4 /*yield*/, singleHook(croakarr)];
                case 2:
                    hook = _a.sent();
                    if (hook === undefined)
                        another = false;
                    if (!another) return [3 /*break*/, 4];
                    return [4 /*yield*/, croakarr.prompt({
                            name: "confirm",
                            message: "Would you like to set up another webhook?",
                            type: "toggle",
                            initial: false,
                            active: "Yes",
                            inactive: "No"
                        })];
                case 3:
                    confirm_1 = (_a.sent()).confirm;
                    another = confirm_1;
                    _a.label = 4;
                case 4:
                    hooks.push(hook);
                    return [3 /*break*/, 1];
                case 5: return [2 /*return*/, hooks];
            }
        });
    });
}
function singleHook(croakarr, logger) {
    return __awaiter(this, void 0, void 0, function () {
        var service_1, serviceDefault, hook;
        var _a;
        return __generator(this, function (_b) {
            switch (_b.label) {
                case 0:
                    _b.trys.push([0, 3, , 4]);
                    service_1 = {
                        service: "discord" //await croakarr.prompt({
                        //     name: "service",
                        //     type: "select",
                        //     message: "Which service would you like to interact with?",
                        //     choices: [
                        //         { title: "Discord" }
                        //     ]
                        // });
                    };
                    serviceDefault = "";
                    switch (service_1.service.toLowerCase()) {
                        case "discord":
                            serviceDefault = "https://discordapp.com/";
                            service_1.formatted = HookService.DISCORD;
                            break;
                        default:
                            serviceDefault = "UNKNOWN SERVICE";
                            service_1.formatted = HookService.UNKNOWN;
                    }
                    _a = {};
                    return [4 /*yield*/, croakarr.prompt({
                            name: "url",
                            type: "text",
                            message: "Enter your webhook URL",
                            default: serviceDefault,
                            validate: function (v) {
                                var valid = HTTP.test(v);
                                if (valid) {
                                    var uri = new URL(v);
                                    switch (service_1.formatted) {
                                        case HookService.DISCORD:
                                            valid = acceptedDomains[HookService.DISCORD].includes(uri.hostname);
                                            break;
                                        default:
                                            valid = false;
                                    }
                                    if (!valid) {
                                        if (service_1.formatted !== HookService.UNKNOWN)
                                            return "Invalid host: Accepted hosts for '".concat(service_1.formatted, "' are: \n - ").concat(acceptedDomains[service_1.formatted].join("\n - "));
                                    }
                                }
                                return valid;
                            }
                        })];
                case 1:
                    _a.url = (_b.sent()).url;
                    return [4 /*yield*/, croakarr.prompt({
                            name: "name",
                            type: "text",
                            message: "What should we call this hook?",
                            default: service_1.service
                        })];
                case 2:
                    hook = (_a.name = (_b.sent()).name,
                        _a);
                    return [2 /*return*/, {
                            name: hook.name,
                            url: hook.url,
                            service: service_1.formatted
                        }];
                case 3:
                    _b.sent();
                    return [2 /*return*/, undefined];
                case 4: return [2 /*return*/];
            }
        });
    });
}
