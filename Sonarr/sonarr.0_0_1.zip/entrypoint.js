'use strict';

Object.defineProperty(exports, "__esModule", { value: true });
exports.disable = exports.enable = void 0;
var logo = "https://avatars.githubusercontent.com/u/1082903";
var url = "https://discordapp.com/api/webhooks/992454432916766930/db_hAFzowWd2uMxY8sam0HXaeSBkvCgDOCOusOwn5AuJwpN8t5dYkTCMy6lojPAXUEll";
function enable(_a) {
    var croakerr = _a.croakerr, logger = _a.logger;
    logger.debug("Incoming log message from Sonarr plugin");
    croakerr.registerListener("sonarr.test", function (data) { return handleTest(croakerr, logger); });
    croakerr.registerListener("sonarr.download", function (data) { return handleDownload(croakerr, logger, data); });
    croakerr.registerListener("sonarr.grab", function (data) { return handleGrab(croakerr, logger, data); });
}
exports.enable = enable;
function disable() {
}
exports.disable = disable;
function handleTest(croakerr, logger, data) {
    logger.log("Received Sonarr test data");
    croakerr.send(url, {
        username: croakerr.manifest.name,
        avatar_url: logo,
        embeds: [
            {
                color: 0x2193B5,
                type: "rich",
                title: "Webhook Test",
                description: "Since this data is probably being used for debugging purposes anyway, here's some information about the plugin which made it.",
                fields: [
                    {
                        name: "Name",
                        value: croakerr.manifest.name,
                        inline: true
                    },
                    {
                        name: "Version",
                        value: croakerr.manifest.version,
                        inline: true
                    },
                    {
                        name: "Author",
                        value: croakerr.manifest.author,
                        inline: true
                    }
                ]
            }
        ]
    });
}
function handleDownload(croakerr, logger, data) {
    logger.log("Received Sonarr download data");
    croakerr.send(url, {
        username: croakerr.manifest.name,
        avatar_url: logo,
        embeds: [
            {
                color: 0x2193B5,
                type: "rich",
                title: "Download completed",
                description: "Show: ".concat(data.series.title, "\nEpisode: S").concat(data.episodes[0].seasonNumber, " - E").concat(data.episodes[0].episodeNumber, " - ").concat(data.episodes[0].title, " (Aired: ").concat(new Date(data.episodes[0].airDate).toLocaleDateString(), ")")
            }
        ]
    });
}
function handleGrab(croakerr, logger, data) {
    logger.log("Received Sonarr grab data");
    croakerr.send(url, {
        username: croakerr.manifest.name,
        avatar_url: logo,
        embeds: [
            {
                color: 0x1a7590,
                type: "rich",
                title: "Download Queued",
                description: "Title: ".concat(data.series.title, "\nQuality: ").concat(data.release.quality, " (").concat(bytesToUnit(data.release.size / 8), ")")
            }
        ]
    });
}
function bytesToUnit(bytes) {
    if (bytes === 0)
        return '0 Bytes';
    var i = parseInt(Math.floor(Math.log(bytes) / Math.log(1024)) + "");
    return Math.round(bytes / Math.pow(1024, i)) + ' ' + ['Bytes', 'KB', 'MB', 'GB', 'TB'][i];
}
